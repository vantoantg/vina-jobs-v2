#Picture Cut#

picture cut is a jquery plugin that handles images in a very friendly and simple way, with a beautiful interface based on bootstrap or jquery ui, has great features like ajax upload, drag image from explorer, image crop and others.

http://picturecut.tuyoshi.com.br/

## Documentation
http://picturecut.tuyoshi.com.br/docs

### Coming soon...  PictureCut 2.0
- All the first version features
- Rewriting the code, changes in the core for better performance
- All the operations done from the client side
- Totally responsive
- Flip, rotate and crop image with canvas

### License

The Picture jQuery is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT)

